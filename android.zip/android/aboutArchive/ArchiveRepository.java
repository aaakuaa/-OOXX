package personal.hbj.android.aboutArchive;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ArchiveRepository extends JpaRepository<Archives, Long> {
}
