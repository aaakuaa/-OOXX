package personal.hbj.android.aboutArchive;

import jakarta.persistence.*;

@Entity
@Table(name = "archives")
public class Archives {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(columnDefinition = "json")
    private String archive1;

    @Column(columnDefinition = "json")
    private String archive2;

    @Column(columnDefinition = "json")
    private String archive3;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getArchive1() {
        return archive1;
    }

    public void setArchive1(String archive1) {
        this.archive1 = archive1;
    }

    public String getArchive2() {
        return archive2;
    }

    public void setArchive2(String archive2) {
        this.archive2 = archive2;
    }

    public String getArchive3() {
        return archive3;
    }

    public void setArchive3(String archive3) {
        this.archive3 = archive3;
    }
// Getters and setters
}
