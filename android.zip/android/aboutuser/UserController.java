package personal.hbj.android.aboutuser;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    public static String Uname = null;

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String register(@RequestBody User user) {
        return userService.register(user);
    }

    @PostMapping("/login")
    public String login(@RequestBody User user, HttpSession session) {
        String loginResult = userService.login(user.getUsername(), user.getPassword());
        if ("登录成功".equals(loginResult)) {
            Uname = user.getUsername();
        }
        System.out.println("Login User: " + Uname);
        return loginResult;
    }

    @GetMapping("/current")
    public String getCurrentUser(HttpSession session) {
        return Uname;
    }
}
