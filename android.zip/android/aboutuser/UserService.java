package personal.hbj.android.aboutuser;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import personal.hbj.android.aboutArchive.Archives;
import personal.hbj.android.aboutArchive.ArchiveRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ArchiveRepository archiveRepository;

    @Transactional
    public String register(User user) {
        // 检查用户名是否已存在
        if (userRepository.findByUsername(user.getUsername()) != null) {
            return "用户名已存在";
        }
        else {
            //信息存入user表
            User savedUser = userRepository.save(user);

            //在表archive当中存入信息
            Archives archive = new Archives();
            archive.setId(savedUser.getId());
            archive.setUsername(savedUser.getUsername());
            archive.setArchive1("{}");
            archive.setArchive2("{}");
            archive.setArchive3("{}");
            archiveRepository.save(archive);

            return "成功注册";
        }

    }

    public String login(String username, String password) {
        User user = userRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return "登录成功";
        } else {
            return "无效用户名或密码";
        }
    }
}
