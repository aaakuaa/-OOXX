package personal.hbj.android.aboutgame;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.util.concurrent.ConcurrentHashMap;

import static personal.hbj.android.aboutuser.UserController.Uname;

@Service
public class GameService {

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private CompareResultRepository compareResultRepository;

    private ConcurrentHashMap<String, Game> activeGames = new ConcurrentHashMap<>();

    public String startGame(String gameId) {

//        String currentUser = (String) session.getAttribute("currentUser");
//        if (currentUser == null) {
//            return "用户未登录.";
//        }
        if(Uname == null ){
            return "异常，用户未登录";
        }

        // 查找现有的游戏实例，如果不存在则创建新的实例
        Game game = activeGames.getOrDefault(gameId, new Game());

        // 检查房间是否已满
        if (game.getPlayer1() != null && game.getPlayer2() != null) {
            return "房间号已被占用.";
        }

        // 设置游戏数据
        if (game.getPlayer1() == null) {
            game.setGameId(gameId);
            game.setPlayer1(Uname);
            game.setStartTime1(System.currentTimeMillis());
        } else if (game.getPlayer2() == null) {
            game.setPlayer2(Uname);
            game.setStartTime2(System.currentTimeMillis());
        }

        // 将游戏实例保存到 activeGames 中
        activeGames.put(gameId, game);

        gameRepository.save(game);

        return "游戏启动成功.";
    }

    public String submitResult(String gameId) {
        String currentUser = Uname;
        if (currentUser == null) {
            return "未登录.";
        }

        // 获取现有的游戏实例
        Game game = activeGames.get(gameId);
        if (game == null) {
            return "房间 " + gameId + " 不存在或已结束.";
        }

        // 根据当前用户更新游戏时间
        if (currentUser.equals(game.getPlayer1())) {
            game.setStartTime1(System.currentTimeMillis() - game.getStartTime1());
        } else if (currentUser.equals(game.getPlayer2())) {
            game.setStartTime2(System.currentTimeMillis() - game.getStartTime2());
        } else {
            return "无效用户.";
        }

        // 更新数据库中的游戏数据
        gameRepository.save(game);

        return "成功结算.";
    }

    public String compareResults(String gameId) {
        // 获取游戏实例
        Game game = gameRepository.findByGameId(gameId);
        if (game == null) {
            return "无效房间号";
        }

        // 获取两位玩家的游戏时间
        long player1Time = game.getStartTime1();
        long player2Time = game.getStartTime2();

        double Time1 = player1Time / 1000.0;
        double Time2 = player2Time / 1000.0;


        if (player1Time == 0 && player2Time > 0) {
            return "对方未完成\n" + game.getPlayer2() + "胜利";
        }else if (player1Time > 0 && player2Time == 0) {
            return "对方未完成\n" + game.getPlayer1() + "胜利";
        }else if (player1Time == 0 && player2Time == 0) {
            return "数据异常";
        }



        // 比较时间，确定输赢结果
        String winner;
        String result = "房间:" + gameId + "\n";
        result += game.getPlayer1() + " 耗时" + Time1 + "秒\n";
        result += game.getPlayer2() + " 耗时" + Time2 + "秒\n";

        if (player1Time < player2Time) {
            result += "  " + game.getPlayer1() + "胜利!";
            winner = game.getPlayer1() + "胜利!";
        } else if (player1Time > player2Time) {
            result += "  " + game.getPlayer2() + "胜利!";
            winner = game.getPlayer2() + "胜利!";
        } else {
            result += "  平局!";
            winner = "平局!";
        }

        // 保存比赛结果到 CompareResult 表
        CompareResult compareResult = new CompareResult();
        compareResult.setGameId(gameId);
        compareResult.setPlayer1Username(game.getPlayer1());
        compareResult.setPlayer2Username(game.getPlayer2());
        compareResult.setPlayer1Time(player1Time);
        compareResult.setPlayer2Time(player2Time);
        compareResult.setResult(result);
        compareResult.setWinner(winner);

        gameRepository.delete(game);

        compareResultRepository.save(compareResult);

        return result;
    }


    @Scheduled(fixedRate = 600000) // 每10分钟运行一次
    public void cleanupIncompleteGames() {
        long now = System.currentTimeMillis();
        for (Game game : activeGames.values()) {
            if ((game.getPlayer1() == null || game.getPlayer2() == null) &&
                    (now - game.getStartTime1() > 600000 || now - game.getStartTime2() > 600000)) {
                gameRepository.delete(game);
                activeGames.remove(game.getGameId());
            }
        }
    }
}

