package personal.hbj.android.aboutgame;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CompareResultRepository extends JpaRepository<CompareResult, Long> {
}