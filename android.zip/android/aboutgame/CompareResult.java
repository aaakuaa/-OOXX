package personal.hbj.android.aboutgame;

import jakarta.persistence.*;

@Entity
public class CompareResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String gameId;
    private String player1Username;
    private String player2Username;
    private long player1Time;
    private long player2Time;
    private String result;
    private String winner;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getPlayer1Username() {
        return player1Username;
    }

    public void setPlayer1Username(String player1Username) {
        this.player1Username = player1Username;
    }

    public String getPlayer2Username() {
        return player2Username;
    }

    public void setPlayer2Username(String player2Username) {
        this.player2Username = player2Username;
    }

    public long getPlayer1Time() {
        return player1Time;
    }

    public void setPlayer1Time(long player1Time) {
        this.player1Time = player1Time;
    }

    public long getPlayer2Time() {
        return player2Time;
    }

    public void setPlayer2Time(long player2Time) {
        this.player2Time = player2Time;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}