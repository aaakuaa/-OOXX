package personal.hbj.android.aboutgame;

import jakarta.persistence.*;

@Entity
public class Game {
    @Id
    private String gameId;

    private String player1;
    private String player2;
    private long startTime1;
    private long startTime2;

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getPlayer1() {
        return player1;
    }

    public void setPlayer1(String player1) {
        this.player1 = player1;
    }

    public String getPlayer2() {
        return player2;
    }

    public void setPlayer2(String player2) {
        this.player2 = player2;
    }

    public long getStartTime1() {
        return startTime1;
    }

    public void setStartTime1(long startTime1) {
        this.startTime1 = startTime1;
    }

    public long getStartTime2() {
        return startTime2;
    }

    public void setStartTime2(long startTime2) {
        this.startTime2 = startTime2;
    }
}