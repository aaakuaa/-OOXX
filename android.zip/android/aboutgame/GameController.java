package personal.hbj.android.aboutgame;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import static personal.hbj.android.aboutuser.UserController.Uname;


@RestController
@RequestMapping("/game")
public class GameController {

    @Autowired
    private GameService gameService;

    @PostMapping("/start")
    public String startGame(@RequestParam String gameId) {
        return gameService.startGame(gameId);
    }

    @PostMapping("/submit")
    public String submitResult(@RequestParam String gameId) {
        return gameService.submitResult(gameId);
    }

    @GetMapping("/compare/{gameId}")
    public String compareResults(@PathVariable String gameId) {
        return gameService.compareResults(gameId);
    }
    
    @PostMapping("/Exit")
    public void rename() {
        Uname = null;
    }
}