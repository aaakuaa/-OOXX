package hbj.game;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.IOException;

import hbj.game.service.MusicService;
import okhttp3.*;

public class LoginActivity extends AppCompatActivity {
    private EditText et_username;
    private EditText et_password;
    private OkHttpClient client;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        //初始化控件
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);
        loginButton = findViewById(R.id.login);

        client = new OkHttpClient();

        //点击注册
        findViewById(R.id.register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到注册页面
                Intent intent =new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);

            }
        });

        //登录
        loginButton.setOnClickListener(view -> {
            String username = et_username.getText().toString();
            String password = et_password.getText().toString();
            new Thread(() -> loginUser(username, password)).start();
        });
    }

    private void loginUser(String username, String password) {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        String json = "{"
                + "\"username\":\"" + username + "\","
                + "\"password\":\"" + password + "\""
                + "}";

        RequestBody body = RequestBody.create(json, JSON);
        // url
        Request request = new Request.Builder()
                .url("http://47.121.113.91:8888/user/login")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, "服务器异常: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                Log.e("loginActivity", "onFailure: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(LoginActivity.this, "服务器异常: " + response.message(), Toast.LENGTH_SHORT).show());
                } else {
                    String responseBody = response.body().string();
                    if("登录成功".equals(responseBody)) {
                        runOnUiThread(() -> Toast.makeText(LoginActivity.this, responseBody, Toast.LENGTH_SHORT).show());
                        //跳转到游戏菜单页面
                        Intent intent =new Intent(LoginActivity.this,MenuActivity.class);
                        startActivity(intent);
                    }else{runOnUiThread(() -> Toast.makeText(LoginActivity.this, responseBody , Toast.LENGTH_SHORT).show());}
                }
            }
        });
    }

}