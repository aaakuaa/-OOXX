package hbj.game;

import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import java.io.IOException;
import okhttp3.*;

public class RegisterActivity extends AppCompatActivity {

    private EditText et_username;
    private EditText et_password;
    private OkHttpClient client;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //初始化控件
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);
        registerButton = findViewById(R.id.register);

        client = new OkHttpClient();

        registerButton.setOnClickListener(view -> {
            String username = et_username.getText().toString();
            String password = et_password.getText().toString();
            new Thread(() -> registerUser(username, password)).start();
        });

        //返回
        findViewById(R.id.toolvar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    //点击注册
    private void registerUser(String username, String password) {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        String json = "{"
                + "\"username\":\"" + username + "\","
                + "\"password\":\"" + password + "\""
                + "}";

        RequestBody body = RequestBody.create(json, JSON);
        // 如果在模拟器上运行，请使用http://10.0.2.2:8888/user/register
        Request request = new Request.Builder()
                .url("http://10.34.122.146:8888/user/register")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(RegisterActivity.this, "服务器异常: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                Log.e("RegisterActivity", "onFailure: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(RegisterActivity.this, "服务器异常: " + response.message(), Toast.LENGTH_SHORT).show());
                } else {
                    String responseBody = response.body().string();
                    if("成功注册".equals(responseBody)) {
                        runOnUiThread(() -> Toast.makeText(RegisterActivity.this, responseBody, Toast.LENGTH_SHORT).show());
                        finish();
                    }else{runOnUiThread(() -> Toast.makeText(RegisterActivity.this, "注册失败" + responseBody, Toast.LENGTH_SHORT).show());}
                }
            }
        });
    }
}
