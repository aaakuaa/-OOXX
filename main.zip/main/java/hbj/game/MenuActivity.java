package hbj.game;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.IOException;

import hbj.game.service.MusicService;
import okhttp3.*;

public class MenuActivity extends AppCompatActivity {
    private static final String TAG = "menu";
    private Button ExitBotton;
    OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.menu);

        Intent musicIntent = new Intent(this, MusicService.class);
        startService(musicIntent);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ExitBotton = findViewById(R.id.Exit);
        ExitBotton.setOnClickListener(view -> {
            new Thread(() -> Exit()).start();
        });

    }

    public void onSinglePlayerClick(View view) {
        Intent intent = new Intent(this, MainActivity11.class);
        startActivity(intent);
    }

    public void onExitClick(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);

        Intent musicIntent = new Intent(this, MusicService.class);
        stopService(musicIntent);

    }

    public void Exit() {

        Intent musicIntent = new Intent(this, MusicService.class);
        stopService(musicIntent);

        // 创建一个无参数的 POST 请求
        Request request = new Request.Builder()
                .url("http://47.121.113.91:8888/game/Exit")
                .post(RequestBody.create(null, new byte[0])) // 使用空的请求体
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // 处理请求失败的情况
                runOnUiThread(() -> Toast.makeText(MenuActivity.this, "服务器异常: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                Log.e("MenuActivity", "onFailure: ", e);
                finishAffinity();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // 处理响应不成功的情况
                    runOnUiThread(() -> Toast.makeText(MenuActivity.this, "账户注销失败: ", Toast.LENGTH_SHORT).show());
                    finishAffinity();
                } else {
                    // 处理响应成功的情况
                    runOnUiThread(() -> Toast.makeText(MenuActivity.this, "账户注销成功: ", Toast.LENGTH_SHORT).show());
                    finishAffinity();
                }
            }
        });

    }

    public void onCreateOrJoinClick(View view) {
        // 创建一个EditText视图，用于输入文本
        final EditText input = new EditText(this);

        OkHttpClient client = new OkHttpClient();
        // 创建一个弹窗对话框
        new AlertDialog.Builder(this)
                .setTitle("创建或者加入一个房间")
                .setMessage("请输入你的房间号：")
                .setView(input)
                .setPositiveButton("确认", (dialog, which) -> {

                    String userInput = input.getText().toString();
                    if (!userInput.isEmpty()) {

                        RequestBody body = new FormBody.Builder()
                                .add("gameId", userInput)  // 将 userInput(参数) 作为 gameId 参数添加到请求体中
                                .build();

                        // 创建 POST 请求
                        Request request = new Request.Builder()
                                .url("http://47.121.113.91:8888/game/start")  // 请求的 URL
                                .post(body)  // 使用构建好的请求体
                                .build();

                        // 发起异步请求
                        client.newCall(request).enqueue(new Callback() {
                            @Override
                            public void onFailure(Call call, IOException e) {
                                // 处理请求失败的情况
                                runOnUiThread(() -> Toast.makeText(MenuActivity.this, "服务器异常: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                                Log.e("MenuActivity", "请求失败", e);
                            }
                            @Override
                            public void onResponse(Call call, Response response) throws IOException {
                                // 处理响应
                                if (response.isSuccessful()) {
                                    // 处理请求成功的情况
                                    String responseBody = response.body().string();
                                    if("游戏启动成功.".equals(responseBody)) {
                                        runOnUiThread(() -> Toast.makeText(MenuActivity.this, responseBody, Toast.LENGTH_SHORT).show());
                                        Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                                        intent.putExtra("room_number", userInput);
                                        Log.d(TAG, "onResponse: "+userInput);
                                        startActivity(intent);
                                    }else{runOnUiThread(() -> Toast.makeText(MenuActivity.this, responseBody, Toast.LENGTH_SHORT).show());}
                                } else {
                                    // 处理请求不成功的情况
                                    runOnUiThread(() -> Toast.makeText(MenuActivity.this, "服务器异常: " + response.message(), Toast.LENGTH_SHORT).show());
                                }
                            }
                        });

                    } else {
                        Toast.makeText(this, "输入不能为空", Toast.LENGTH_LONG).show();
                    }

                })
                .setNegativeButton("取消", (dialog, which) -> dialog.cancel()).show();
    }
}