package hbj.game;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity11 extends AppCompatActivity {

    private int[][] buttonImages = {
            {1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 2, 1, 1, 1},
            {1, 1, 1, 2, 1, 1, 1},
            {1, 2, 1, 1, 1, 1, 2},
            {1, 1, 1, 3, 1, 1, 1},
            {1, 1, 2, 1, 1, 1, 2},
            {1, 3, 1, 1, 1, 3, 1}
    };
    private int[][] initialButtonImages = {
            {1, 1, 1, 1, 1, 1, 1},
            {1, 1, 1, 2, 1, 1, 1},
            {1, 1, 1, 2, 1, 1, 1},
            {1, 2, 1, 1, 1, 1, 2},
            {1, 1, 1, 3, 1, 1, 1},
            {1, 1, 2, 1, 1, 1, 2},
            {1, 3, 1, 1, 1, 3, 1}
    };
    private int[][] answerArray = {
            {1, 1, 1, 1, 1, 1, 1},
            {1, 2, 3, 2, 3, 2, 3},
            {1, 3, 2, 2, 3, 2, 3},
            {1, 2, 3, 3, 2, 3, 2},
            {1, 2, 3, 3, 2, 2, 3},
            {1, 3, 2, 2, 3, 3, 2},
            {1, 3, 2, 3, 2, 3, 2}
    };

    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button15;
    private Button button22;
    private Button button29;
    private Button button36;
    private Button button43;
    private GridLayout gridLayout;

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);

        gridLayout = findViewById(R.id.gridLayout11);

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                Button button = new Button(this);

                GradientDrawable border = new GradientDrawable();
                int buttonNumber = i * 7 + j + 1;

                if (i == 0 || buttonNumber == 15 || buttonNumber == 29 || buttonNumber == 43) {
                    border.setColor(Color.WHITE);
                } else if (buttonNumber % 2 == 1) {
                    border.setColor(Color.LTGRAY);
                } else {
                    border.setColor(Color.WHITE);
                }

                border.setStroke(2, Color.BLACK);
                button.setBackground(border);

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.rowSpec = GridLayout.spec(i, 1);
                params.columnSpec = GridLayout.spec(j, 1);
                params.width = 150;
                params.height = 150;
                params.setMargins(2, 2, 2, 2);
                button.setLayoutParams(params);

                int imageResource = getResources().getIdentifier("image" + buttonImages[i][j], "drawable", getPackageName());
                button.setForeground(getResources().getDrawable(imageResource, null));

                if(buttonNumber==2){
                    button2=button;
                }
                if(buttonNumber==3){
                    button3=button;
                }
                if(buttonNumber==4){
                    button4=button;
                }
                if(buttonNumber==5){
                    button5=button;
                }
                if(buttonNumber==6){
                    button6=button;
                }
                if(buttonNumber==7){
                    button7=button;
                }
                if(buttonNumber==8){
                    button8=button;
                }
                if(buttonNumber==15){
                    button15=button;
                }
                if(buttonNumber==22){
                    button22=button;
                }
                if(buttonNumber==29){
                    button29=button;
                }
                if(buttonNumber==36){
                    button36=button;
                }
                if(buttonNumber==43){
                    button43=button;
                }

                if (!(buttonNumber == 11 || buttonNumber == 18 || buttonNumber == 23 || buttonNumber == 28 ||
                        buttonNumber == 32 || buttonNumber == 38 || buttonNumber == 42 || buttonNumber == 44 || buttonNumber == 48)){
                    if ((buttonNumber >= 9 && buttonNumber <= 14) ||
                            (buttonNumber >= 16 && buttonNumber <= 21) ||
                            (buttonNumber >= 24 && buttonNumber <= 28) ||
                            (buttonNumber >= 30 && buttonNumber <= 35) ||
                            (buttonNumber >= 37 && buttonNumber <= 41) ||
                            (buttonNumber >= 44 && buttonNumber <= 49)) {

                        final int rowIndex = i;
                        final int colIndex = j;

                        button.setOnClickListener(new View.OnClickListener() {
                            int imageIndex = buttonImages[rowIndex][colIndex] - 1;
                            int[] images = {R.drawable.image1, R.drawable.image2, R.drawable.image3};

                            @Override
                            public void onClick(View v) {
                                imageIndex = (imageIndex + 1) % images.length;
                                button.setForeground(getResources().getDrawable(images[imageIndex], null));
                                buttonImages[rowIndex][colIndex] = imageIndex + 1;
                                printButtonImages();
                                if (compareArrays()) {
                                    Toast.makeText(MainActivity11.this, "答案正确!", Toast.LENGTH_SHORT).show();
                                }
                                if(tips2()==1){
                                    button2.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips2()==2){
                                    button2.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips2()==0){
                                    button2.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips3()==1){
                                    button3.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips3()==2){
                                    button3.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips3()==0){
                                    button3.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips4()==1){
                                    button4.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips4()==2){
                                    button4.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips4()==0){
                                    button4.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips5()==1){
                                    button5.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips5()==2){
                                    button5.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips5()==0){
                                    button5.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips6()==1){
                                    button6.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips6()==2){
                                    button6.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips6()==0){
                                    button6.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips7()==1){
                                    button7.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips7()==2){
                                    button7.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips7()==0){
                                    button7.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips8()==1){
                                    button8.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips8()==2){
                                    button8.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips8()==0){
                                    button8.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips15()==1){
                                    button15.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips15()==2){
                                    button15.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips15()==0){
                                    button15.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips22()==1){
                                    button22.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips22()==2){
                                    button22.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips22()==0){
                                    button22.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips29()==1){
                                    button29.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips29()==2){
                                    button29.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips29()==0){
                                    button29.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips36()==1){
                                    button36.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips36()==2){
                                    button36.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips36()==0){
                                    button36.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                                if(tips43()==1){
                                    button43.setForeground(getResources().getDrawable(R.drawable.image4));
                                }
                                else if (tips43()==2){
                                    button43.setForeground(getResources().getDrawable(R.drawable.image5));
                                }
                                else if (tips43()==0){
                                    button43.setForeground(getResources().getDrawable(R.drawable.image1));
                                }
                            }
                        });
                    }
                }

                gridLayout.addView(button);
            }
        }

        Button squareButton1 = findViewById(R.id.squareButton111);
        squareButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetButtonImages();
                Toast.makeText(MainActivity11.this, "谜题已重置", Toast.LENGTH_SHORT).show();
            }
        });

        Button squareButton2 = findViewById(R.id.squareButton211);
        squareButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAnswer();
                Toast.makeText(MainActivity11.this, "答案已显示", Toast.LENGTH_SHORT).show();
                button2.setForeground(getResources().getDrawable(R.drawable.image4));
                button3.setForeground(getResources().getDrawable(R.drawable.image4));
                button4.setForeground(getResources().getDrawable(R.drawable.image4));
                button5.setForeground(getResources().getDrawable(R.drawable.image4));
                button6.setForeground(getResources().getDrawable(R.drawable.image4));
                button7.setForeground(getResources().getDrawable(R.drawable.image4));
                button8.setForeground(getResources().getDrawable(R.drawable.image4));
                button15.setForeground(getResources().getDrawable(R.drawable.image4));
                button22.setForeground(getResources().getDrawable(R.drawable.image4));
                button29.setForeground(getResources().getDrawable(R.drawable.image4));
                button36.setForeground(getResources().getDrawable(R.drawable.image4));
                button43.setForeground(getResources().getDrawable(R.drawable.image4));
            }
        });
    }
    //重置
    private void resetButtonImages() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                buttonImages[i][j] = initialButtonImages[i][j];
                int imageResource = getResources().getIdentifier("image" + initialButtonImages[i][j], "drawable", getPackageName());
                int buttonNumber = i * 7 + j + 1;

                Button button = (Button) gridLayout.getChildAt(buttonNumber - 1);
                button.setForeground(getResources().getDrawable(imageResource, null));
            }
        }
    }
    //显示答案
    private void showAnswer() {
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                buttonImages[i][j] = answerArray[i][j];
                int imageResource = getResources().getIdentifier("image" + answerArray[i][j], "drawable", getPackageName());
                int buttonNumber = i * 7 + j + 1;

                Button button = (Button) gridLayout.getChildAt(buttonNumber - 1);
                button.setForeground(getResources().getDrawable(imageResource, null));
            }
        }
    }

    private void printButtonImages() {
        for (int[] row : buttonImages) {
            for (int cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }

    private boolean compareArrays() {
        for (int i = 0; i < buttonImages.length; i++) {
            for (int j = 0; j < buttonImages[i].length; j++) {
                if (buttonImages[i][j] != answerArray[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    //提示
    private int tips2() {
        for (int i = 0; i < 7; i++) {
            if (buttonImages[i][1] != answerArray[i][1]) {
                if(buttonImages[1][1]==1||buttonImages[2][1]==1||buttonImages[3][1]==1||buttonImages[4][1]==1||buttonImages[5][1]==1||buttonImages[6][1]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips3() {
        for (int i = 0; i < 7; i++) {
            if (buttonImages[i][2] != answerArray[i][2]) {
                if(buttonImages[1][2]==1||buttonImages[2][2]==1||buttonImages[3][2]==1||buttonImages[4][2]==1||buttonImages[5][2]==1||buttonImages[6][2]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips4() {
        for (int i = 0; i < 7; i++) {
            if (buttonImages[i][3] != answerArray[i][3]) {
                if(buttonImages[1][3]==1||buttonImages[2][3]==1||buttonImages[3][3]==1||buttonImages[4][3]==1||buttonImages[5][3]==1||buttonImages[6][3]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips5() {
        for (int i = 0; i < 7; i++) {
            if (buttonImages[i][4] != answerArray[i][4]) {
                if(buttonImages[1][4]==1||buttonImages[2][4]==1||buttonImages[3][4]==1||buttonImages[4][4]==1||buttonImages[5][4]==1||buttonImages[6][4]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips6() {
        for (int i = 0; i < 7; i++) {
            if (buttonImages[i][5] != answerArray[i][5]) {
                if(buttonImages[1][5]==1||buttonImages[2][5]==1||buttonImages[3][5]==1||buttonImages[4][5]==1||buttonImages[5][5]==1||buttonImages[6][5]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips7() {
        for (int i = 0; i < 7; i++) {
            if (buttonImages[i][6] != answerArray[i][6]) {
                if(buttonImages[1][6]==1||buttonImages[2][6]==1||buttonImages[3][6]==1||buttonImages[4][6]==1||buttonImages[5][6]==1||buttonImages[6][6]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips8() {
        for (int j = 0; j < 7; j++) {
            if (buttonImages[1][j] != answerArray[1][j]) {
                if(buttonImages[1][1]==1||buttonImages[1][2]==1||buttonImages[1][3]==1||buttonImages[1][4]==1||buttonImages[1][5]==1||buttonImages[1][6]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips15() {
        for (int j = 0; j < 7; j++) {
            if (buttonImages[2][j] != answerArray[2][j]) {
                if(buttonImages[2][1]==1||buttonImages[2][2]==1||buttonImages[2][3]==1||buttonImages[2][4]==1||buttonImages[2][5]==1||buttonImages[2][6]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips22() {
        for (int j = 0; j < 7; j++) {
            if (buttonImages[3][j] != answerArray[3][j]) {
                if(buttonImages[3][1]==1||buttonImages[3][2]==1||buttonImages[3][3]==1||buttonImages[3][4]==1||buttonImages[3][5]==1||buttonImages[3][6]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips29() {
        for (int j = 0; j < 7; j++) {
            if (buttonImages[4][j] != answerArray[4][j]) {
                if(buttonImages[4][1]==1||buttonImages[4][2]==1||buttonImages[4][3]==1||buttonImages[4][4]==1||buttonImages[4][5]==1||buttonImages[4][6]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips36() {
        for (int j = 0; j < 7; j++) {
            if (buttonImages[5][j] != answerArray[5][j]) {
                if(buttonImages[5][1]==1||buttonImages[5][2]==1||buttonImages[5][3]==1||buttonImages[5][4]==1||buttonImages[5][5]==1||buttonImages[5][6]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    private int tips43() {
        for (int j = 0; j < 7; j++) {
            if (buttonImages[6][j] != answerArray[6][j]) {
                if(buttonImages[6][1]==1||buttonImages[6][2]==1||buttonImages[6][3]==1||buttonImages[6][4]==1||buttonImages[6][5]==1||buttonImages[6][6]==1){
                    return 0;
                }
                return 2;
            }
        }
        return 1;
    }
    public void onClick2(View view){
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }

}
